package com.example.listadecompra.model

data class UserData (
    var userName:String,
    var userMb:String
)