package com.example.crud_room_kotlin

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
// se crea la consulta de la base de datos.
@Dao
interface DaoUsuario {

    @Query("SELECT * FROM usuarios")
    suspend fun obtenerUsuarios(): MutableList<Usuario>

    @Insert
    suspend fun agregarUsuario(usuario: Usuario)

    @Query("UPDATE usuarios set pais=:pais WHERE usuario=:usuario")
    suspend fun actualizarUsuario(usuario: String, pais: String)

    @Query("DELETE FROM usuarios WHERE usuario=:usuario")
    suspend fun borrarUsuario(usuario: String)

}